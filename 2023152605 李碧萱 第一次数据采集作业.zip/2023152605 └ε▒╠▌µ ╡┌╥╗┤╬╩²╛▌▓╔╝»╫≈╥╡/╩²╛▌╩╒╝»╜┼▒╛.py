#作者：李碧萱
#学号:2023152605
#第一次作业：数据搜集
#本代码文件提交时计算过 SHA-256 值以验证原创性，相关值见报告。

import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
import os  # 新增

headers = {
    'User-Agent': 'Mozilla/5.0'
}

comments = []

for i in range(0, 100, 20):  # 分页，每页20条
    url = f"https://movie.douban.com/subject/35372742/comments?start={i}&limit=20&status=P&sort=new_score"
    res = requests.get(url, headers=headers)
    soup = BeautifulSoup(res.text, 'html.parser')

    comment_divs = soup.find_all('div', class_='comment-item')
    for div in comment_divs:
        user = div.find('span', class_='comment-info').a.text
        rating_tag = div.find('span', class_='rating')
        rating = rating_tag['title'] if rating_tag else '无评分'
        date = div.find('span', class_='comment-time')['title']
        content = div.find('span', class_='short').text
        useful = div.find('span', class_='votes').text

        comments.append({
            '用户': user,
            '评分': rating,
            '时间': date,
            '评论内容': content,
            '有用数': useful
        })

    time.sleep(1)

# 获取代码文件所在的目录
script_dir = os.path.dirname(os.path.abspath(__file__))
output_path = os.path.join(script_dir, '无名电影评论数据.csv')

df = pd.DataFrame(comments)
df.to_csv(output_path, index=False, encoding='utf-8-sig')
print(f"数据已保存到：{output_path}")
