#作者：李碧萱
#学号:2023152605
#第二次作业：案例理解：现实到抽象建模与计算
#本代码文件提交时计算过 SHA-256 值以验证原创性，相关值见报告。

# 运行前需安装依赖库：
# pip install scikit-learn numpy pandas matplotlib
import numpy as np
import pandas as pd
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, roc_curve, auc
import matplotlib.pyplot as plt
import matplotlib
import os
import sys
import platform

# 打印环境信息，便于调试
print(f"Python 版本: {sys.version}")
print(f"操作系统: {platform.system()} {platform.release()}")

# 设置matplotlib支持中文字体，添加备选字体
matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']  # 优先SimHei，备选其他字体
matplotlib.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 获取脚本所在目录
try:
    script_dir = os.path.dirname(os.path.abspath(__file__))
except NameError:
    # 如果__file__不可用（交互式环境），使用当前工作目录
    script_dir = os.getcwd()
    print("警告: 未检测到脚本文件路径，使用当前工作目录")
print("保存文件的目录:", script_dir)

# 确保目录存在
try:
    os.makedirs(script_dir, exist_ok=True)
except Exception as e:
    print(f"创建目录失败: {e}")

# 1. 生成并保存垃圾邮件数据集（作业要求：生成100个样本）
np.random.seed(42)
n_samples = 100
x1 = np.random.randint(0, 2, n_samples)  # 是否包含“促销”关键词
x2 = np.random.randint(0, 2, n_samples)  # 是否在夜间发送
y = (x1 + x2) > 0
# 添加10%标签噪声
noise = np.random.choice([0, 1], size=n_samples, p=[0.9, 0.1])  # 10%概率翻转标签
y = y.astype(int) ^ noise

# 创建并保存DataFrame
data = pd.DataFrame({'x1': x1, 'x2': x2, 'y': y})
try:
    data.to_csv(os.path.join(script_dir, '垃圾邮件数据集.csv'), index=False)
    print("成功保存: 垃圾邮件数据集.csv")
except Exception as e:
    print(f"保存 垃圾邮件数据集.csv 失败: {e}")

# 加载数据集
X = data[['x1', 'x2']].values
y = data['y'].values

# 2. 方法一：使用train_test_split进行随机划分（作业要求：test_size=0.2）
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 创建并训练SVM模型（作业要求：线性核）
svm_model = SVC(kernel='linear', probability=True)
svm_model.fit(X_train, y_train)

# 预测
y_pred = svm_model.predict(X_test)
y_pred_proba = svm_model.predict_proba(X_test)[:, 1]

# 评估（作业要求：准确率、精确率、召回率、F1值、混淆矩阵）
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred, zero_division=0)
recall = recall_score(y_test, y_pred, zero_division=0)
f1 = f1_score(y_test, y_pred, zero_division=0)
conf_matrix = confusion_matrix(y_test, y_pred)

# 打印并保存评估结果
split_results = [
    "train_test_split 评估结果：",
    f"准确率: {accuracy:.4f}",
    f"精确率: {precision:.4f}",
    f"召回率: {recall:.4f}",
    f"F1值: {f1:.4f}",
    "混淆矩阵:",
    str(conf_matrix)
]
print("\n".join(split_results))

try:
    with open(os.path.join(script_dir, '模型评估结果.txt'), 'w', encoding='utf-8') as f:
        f.write("\n".join(split_results) + "\n\n")
    print("成功保存: 模型评估结果.txt")
except Exception as e:
    print(f"保存 模型评估结果.txt 失败: {e}")

# 绘制混淆矩阵（作业要求：可视化混淆矩阵）
plt.figure(figsize=(6, 4))
plt.imshow(conf_matrix, interpolation='nearest', cmap=plt.cm.Blues)
plt.title('混淆矩阵')
plt.colorbar()
tick_marks = np.arange(2)
plt.xticks(tick_marks, ['正常邮件', '垃圾邮件'])
plt.yticks(tick_marks, ['正常邮件', '垃圾邮件'])
thresh = conf_matrix.max() / 2.
for i in range(conf_matrix.shape[0]):
    for j in range(conf_matrix.shape[1]):
        plt.text(j, i, f"{conf_matrix[i, j]}\n({conf_matrix[i, j]/conf_matrix.sum()*100:.1f}%)",
                 horizontalalignment="center",
                 color="white" if conf_matrix[i, j] > thresh else "black")
plt.tight_layout()
plt.ylabel('真实标签')
plt.xlabel('预测标签')
try:
    plt.savefig(os.path.join(script_dir, '混淆矩阵图.png'))
    print("成功保存: 混淆矩阵图.png")
except Exception as e:
    print(f"保存 混淆矩阵图.png 失败: {e}")
plt.close()

# 计算并绘制ROC曲线（作业要求：可视化ROC曲线和AUC）
fpr, tpr, _ = roc_curve(y_test, y_pred_proba)
roc_auc = auc(fpr, tpr)
plt.figure(figsize=(6, 4))
plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC曲线 (AUC = {roc_auc:.2f})')
plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('假阳性率')
plt.ylabel('真阳性率')
plt.title('ROC曲线')
plt.legend(loc="lower right")
try:
    plt.savefig(os.path.join(script_dir, 'ROC曲线图.png'))
    print("成功保存: ROC曲线图.png")
except Exception as e:
    print(f"保存 ROC曲线图.png 失败: {e}")
plt.close()

# 3. 方法二：使用StratifiedKFold进行交叉验证（作业要求：3折分层交叉验证）
skf = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
accuracies, precisions, recalls, f1_scores, auc_scores = [], [], [], [], []

for train_index, test_index in skf.split(X, y):
    X_train, X_test = X[train_index], X[test_index]
    y_train, y_test = y[train_index], y[test_index]
    
    # 创建并训练模型
    svm_model = SVC(kernel='linear', probability=True)
    svm_model.fit(X_train, y_train)
    
    # 预测
    y_pred = svm_model.predict(X_test)
    y_pred_proba = svm_model.predict_proba(X_test)[:, 1]
    
    # 评估
    accuracies.append(accuracy_score(y_test, y_pred))
    precisions.append(precision_score(y_test, y_pred, zero_division=0))
    recalls.append(recall_score(y_test, y_pred, zero_division=0))
    f1_scores.append(f1_score(y_test, y_pred, zero_division=0))
    fpr, tpr, _ = roc_curve(y_test, y_pred_proba)
    auc_scores.append(auc(fpr, tpr))

# 打印并保存交叉验证平均结果
cv_results = [
    "StratifiedKFold 交叉验证平均结果：",
    f"平均准确率: {np.mean(accuracies):.4f} (±{np.std(accuracies):.4f})",
    f"平均精确率: {np.mean(precisions):.4f} (±{np.std(precisions):.4f})",
    f"平均召回率: {np.mean(recalls):.4f} (±{np.std(recalls):.4f})",
    f"平均F1值: {np.mean(f1_scores):.4f} (±{np.std(f1_scores):.4f})",
    f"平均AUC: {np.mean(auc_scores):.4f} (±{np.std(auc_scores):.4f})"
]
print("\n".join(cv_results))

try:
    with open(os.path.join(script_dir, '模型评估结果.txt'), 'a', encoding='utf-8') as f:
        f.write("\n".join(cv_results))
    print("成功追加: 模型评估结果.txt")
except Exception as e:
    print(f"追加 模型评估结果.txt 失败: {e}")

# 保存指标到CSV（增强：结构化输出）
try:
    results_df = pd.DataFrame({
        'Method': ['train_test_split', 'StratifiedKFold'],
        'Accuracy': [accuracy, np.mean(accuracies)],
        'Precision': [precision, np.mean(precisions)],
        'Recall': [recall, np.mean(recalls)],
        'F1': [f1, np.mean(f1_scores)],
        'AUC': [roc_auc, np.mean(auc_scores)]
    })
    results_df.to_csv(os.path.join(script_dir, '评估指标汇总.csv'), index=False)
    print("成功保存: 评估指标汇总.csv")
except Exception as e:
    print(f"保存 评估指标汇总.csv 失败: {e}")